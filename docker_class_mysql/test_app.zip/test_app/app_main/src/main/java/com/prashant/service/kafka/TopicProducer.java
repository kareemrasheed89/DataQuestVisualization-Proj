package com.prashant.service.kafka;

import com.prashant.service.model.UserRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class TopicProducer {
    private static final Logger logger = LoggerFactory.getLogger(TopicProducer.class);
    private static final String TOPIC = "topic2";

    @Autowired
    private KafkaTemplate<String, UserRequest> kafkaTemplate;

    public void sendMessage(UserRequest message){
        logger.info(String.format("$$ -> Sending message --> %s",message.getEmail()));
        this.kafkaTemplate.send(TOPIC, message);
        logger.info(String.format("$$ -> Sent message --> %s",message.getEmail()));
    }
}