package com.prashant.service.handler;


import com.prashant.service.model.User;
import com.prashant.service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserHandler {
    @Autowired
    UserRepository userRepository;

    public void handleUserAdd(User userEntity) throws IllegalArgumentException {
        userRepository.save(userEntity);
    }

    public Iterable<User> allUsers() {
        return userRepository.findAll();
    }
}
