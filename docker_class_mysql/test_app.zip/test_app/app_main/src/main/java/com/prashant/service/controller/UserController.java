package com.prashant.service.controller;

import com.prashant.service.handler.UserHandler;
import com.prashant.service.kafka.TopicProducer;
import com.prashant.service.model.User;
import com.prashant.service.model.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {
    @Autowired
    private UserHandler userHandler;

    @Autowired
    TopicProducer topicProducer;

    @PostMapping("/add")
    public ResponseEntity<HttpStatus> addNewUser(@RequestBody UserRequest request) {
        User addUser = new User();
        addUser.setName(request.getName());
        addUser.setEmail(request.getEmail());
        userHandler.handleUserAdd(addUser);
        topicProducer.sendMessage(request);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping(path="/all")
    public @ResponseBody Iterable<User> getAllUsers() {
        return userHandler.allUsers();
    }
}
